package lab4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class CubeSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number, sum;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Enter Number ");
			number = Integer.parseInt(bufferedReader.readLine());
			sum = findCubeSum(number);
			System.out.println(sum);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static int findCubeSum(int number) {

		 int temp,sum;
		 sum = 0;
		 int remainder;
		 while(number>0)
		 {
			remainder = number % 10;
			sum += Math.pow(remainder,3);
			number /= 10;
		 }
		 return sum;
	}

}
