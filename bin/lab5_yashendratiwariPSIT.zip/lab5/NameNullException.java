package lab5;

public class NameNullException extends Exception{

	public NameNullException(String s) 
	{
		super(s);
	}
}
