package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Employee {
	private int empId;
	private String name;
	private int age;
	private int salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Employee emp = new Employee();
		System.out.println("Enter Employee Id :");
		try {
		int empId = Integer.parseInt(br.readLine());
		emp.setEmpId(empId);
		System.out.println("Enter Employee Name :");
		String name = br.readLine();
		emp.setName(name);
		System.out.println("Enter Employee Age :");
		int age = Integer.parseInt(br.readLine());
		System.out.println("Enter Employee Salary :");
		int salary = Integer.parseInt(br.readLine());
		if(age<3000)
			throw new EmployeeException("Employee Salary is very low.");
		else
			System.out.println("Your age is "+age);
		}catch(IOException e)
		{
			e.printStackTrace();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 System.out.println("Salary of an Employee is less than 3000.");
		}

	}
}
