package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Fibonacci {

	public static void main(String[] args) {
		int n;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			int nrec = recursiveFib(n);
			System.out.println("Using Recusrsion : "+nrec);
			int nit = iterativeFib(n);
			System.out.println("Using Iteration : "+nit);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	  static int iterativeFib(int n) {
		int first = 1;
		int second = 1;
		int count = 2;
		int temp = 0;
		while(count <= n)
		{
			temp = second;
			second = second + first;
			first = temp;
			n--;
		}
		return temp;
	}

	static int recursiveFib(int n) {
		if(n<=1)
			return n;
		else
			return (recursiveFib(n-1)+recursiveFib(n-2));
	}

}
