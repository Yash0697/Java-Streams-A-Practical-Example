package lab5;

public class EmployeeException extends Exception {

	public EmployeeException(String s)
	{
		super(s);
	}
}
