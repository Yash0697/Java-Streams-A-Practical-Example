package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AgeValidator {

	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Age :");
		try {
		int age = Integer.parseInt(br.readLine());
		if(age<=15)
			throw new AgeLowException("Your Age is too low.");
		else
			System.out.println("Your age is "+age);
		}catch(IOException e)
		{
			e.printStackTrace();
		} catch (AgeLowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 System.out.println("Come here when you are 16.");
		}

	}

}
