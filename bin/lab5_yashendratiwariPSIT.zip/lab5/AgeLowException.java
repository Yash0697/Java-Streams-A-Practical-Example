package lab5;

public class AgeLowException extends Exception{

	public AgeLowException(String s)
	{
		super(s);
	}
}
