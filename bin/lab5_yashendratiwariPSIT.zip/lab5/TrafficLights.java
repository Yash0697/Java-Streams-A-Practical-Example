package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TrafficLights {

	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("1.red\n2.yellow\n3.green");
		try {
			int choice = Integer.parseInt(br.readLine());
			
			switch(choice)
			{
			case 1:System.out.println("stop");
			break;
			case 2:
				System.out.println("ready");
			break;
			case 3: System.out.println("go");
			break;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
