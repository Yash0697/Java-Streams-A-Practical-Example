package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class NameValidator {

	public static void main(String[] args) {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter First Name :");
		try {
		String firstName = br.readLine();
		System.out.println("Enter Last Name :");
		String lastName = br.readLine();
		if(firstName.isBlank() && lastName.isBlank())
			throw new NameNullException("No Valid Name Entered.");
		else
			System.out.println("Your Name is "+firstName+" "+lastName);
		}catch(IOException e)
		{
			e.printStackTrace();
		} catch (NameNullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 System.out.println("You Need to Enter Someting");
		}
	}

}
