package lab5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimePrinter {

	public static void main(String[] args) {
		int n;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			printPrimes(n);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	 static void printPrimes(int n) {
		int i = 2,j;
		if(n>=2)
		System.out.print(2+" ");
		while(i<=n)
		{
			boolean flag = true;
			for(j=2;j<=Math.ceil(Math.sqrt(i));j++)
			{
				if(i % j == 0)
					{
					flag = false;
					break;
					}
				
			}
			if(flag==true)
				System.out.print(i+" ");
			i++;
		}
		
	}

}
