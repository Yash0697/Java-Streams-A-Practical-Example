package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ValidVoter {

	public static void main(String[] args) {
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		boolean flag = true;
		try {
		while(flag==true)
		{
			System.out.println("Enter ID and Age ");
			hm.put(Integer.parseInt(br.readLine()), Integer.parseInt(br.readLine()));
			System.out.println("Do you want to enter More value ?");
			if(br.readLine().equalsIgnoreCase("yes"))
				continue;
			else
				break;
		}
		ArrayList<Integer> ans = new ArrayList<Integer>();
		ans = voterList(hm);
		Iterator<Integer> it = ans.iterator();
		if(ans.size()>0) {
		while(it.hasNext())
		{
			System.out.println(it.next()+" is a valid voter");
		}
		}
		else
			System.out.println("None of the persons is a valid voter");
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	static ArrayList<Integer> voterList(HashMap<Integer, Integer> hm) {
		ArrayList<Integer> ans = new ArrayList<Integer>();
		for(int key:hm.keySet())
		{
			if(hm.get(key)>=18)
			{
				ans.add(key);
			}
		}
		return ans;
	}

}
