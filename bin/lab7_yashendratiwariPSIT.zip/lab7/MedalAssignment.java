package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class MedalAssignment {

	public static void main(String[] args) {
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		boolean flag = true;
		try {
		while(flag==true)
		{
			System.out.println("Enter Registration No and Marks ");
			hm.put(Integer.parseInt(br.readLine()), Integer.parseInt(br.readLine()));
			System.out.println("Do you want to enter More value ?");
			if(br.readLine().equalsIgnoreCase("yes"))
				continue;
			else
				break;
		}
		HashMap<Integer, String> ans = new HashMap<Integer, String>();
		ans = getStudents(hm);
		System.out.println("Registration No.  Medal Won");
		 for (Integer Key : ans.keySet())
		 {
			 System.out.println(Key+":\t"+ans.get(Key));
		 }
	}catch(IOException e)
		{
		e.printStackTrace();
		}
	}

	 static HashMap<Integer, String> getStudents(HashMap<Integer, Integer> hm) {
		 HashMap<Integer, String> ans = new HashMap<Integer, String>();
		 for(Integer key:hm.keySet())
		 {
			 if(hm.get(key)>=90)
				 ans.put(key,"Gold");
		
		 else if(hm.get(key)>=80 && hm.get(key) < 90)
		 {
			 ans.put(key,"Silver");
		 }
		 else if(hm.get(key) >= 70 && hm.get(key) < 80)
		 {
			 ans.put(key,"Bronze");
		 }
		 }
		return ans;
	}

}
