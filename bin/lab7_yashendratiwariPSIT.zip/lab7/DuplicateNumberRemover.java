package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class DuplicateNumberRemover {

	public static void main(String[] args) {
		int n,i;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number of numbers in array :");
		try {
			n = Integer.parseInt(br.readLine());
			int[] numbers = new int[n];
			System.out.println("Enter "+n+" numbers");
			for(i=0;i<n;i++)
			{
				numbers[i] = Integer.parseInt(br.readLine());
			}
			int[] ans = modifyArray(numbers);
			System.out.println("Array after removing duplicates is :");
			for(i=0;i<ans.length;i++)
			{
				System.out.print(ans[i]+" ");
			}
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static int[] modifyArray(int[] numbers) {
		Set<Integer>numSet = new HashSet<Integer>();
		for(int num:numbers)
		{
			numSet.add(num);
		}
		int[] arr = new int[numSet.size()];
		int j = 0;
		for(int i:numSet)
		{
			arr[j++]=i ;
		}
		return arr;
	}

}
