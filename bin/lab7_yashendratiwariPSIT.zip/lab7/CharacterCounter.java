package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class CharacterCounter {

	public static void main(String[] args) {
		int numOfChars, index;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Characters : ");
		try {
			numOfChars = Integer.parseInt(bufferedReader.readLine());
			char[] characters = new char[numOfChars];
			System.out.println("Enter "+numOfChars+" chracters");
			for(index = 0; index < numOfChars; index++)
			{
				characters[index] = sc.next().charAt(0);
			}
			HashMap<Character, Integer> ans = countCharacters(characters);
			System.out.print("{");
			for(char ch:ans.keySet())
			{
				System.out.print(ch+": "+ans.get(ch)+" ");
			}
			System.out.println("}");
			sc.close();
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	 static HashMap<Character, Integer> countCharacters(char[] characters) {
		HashMap<Character, Integer> counter = new HashMap<Character, Integer>();
		Set<Character> charSet = new HashSet<>();
		for(char ch:characters)
		{
			charSet.add(ch);
		}
		for(char ch:charSet)
		{
			counter.put(ch, 0);
		}
		for(char ch:characters)
		{
			counter.put(ch,counter.get(ch)+1);
		}
		return counter;
	}

}
