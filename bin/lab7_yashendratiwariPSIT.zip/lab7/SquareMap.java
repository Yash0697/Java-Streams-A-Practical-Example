package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class SquareMap {

	public static void main(String[] args) {
		int n;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number of elements in array : ");
		try {
			n = Integer.parseInt(br.readLine());
			int[] arr = new int[n];
			System.out.println("Enter "+n+" elements in array");
			for(int i = 0;i<n;i++)
			{
				arr[i] = Integer.parseInt(br.readLine());
			}
			HashMap<Integer, Integer> ans = new HashMap<Integer, Integer>();
			ans = getSquares(arr);
			 for (Integer Key : ans.keySet())
			 {
				 System.out.println(Key+":\t"+ans.get(Key));
			 }
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	 static HashMap<Integer, Integer> getSquares(int[] arr) {
		int i;
		HashMap<Integer, Integer> ans = new HashMap<Integer, Integer>();
		for(i=0;i<arr.length;i++)
		{
			int square = arr[i]*arr[i];
			ans.put(arr[i],square);
		}
		return ans;
	}

}
