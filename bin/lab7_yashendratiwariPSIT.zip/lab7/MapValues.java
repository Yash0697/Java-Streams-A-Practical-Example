package lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class MapValues {

	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Keys and values in map : ");
		boolean flag = true;
		try {
		while(flag==true)
		{
			
				hm.put(Integer.parseInt(br.readLine()), br.readLine());
				System.out.println("Do you want to enter more ? ");
				if(br.readLine().equalsIgnoreCase("yes"))
					continue;
				else
					break;
		}
		List<String> ar = getValues(hm);
		System.out.println("Values in Sorted Order are : ");
		Iterator<String> arIterator  = ar.iterator();
		while(arIterator.hasNext())
		{
			System.out.println(arIterator.next());
		}
		}catch (NumberFormatException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	 static List<String> getValues(HashMap<Integer, String> hm) {
		 List<String> arl = new ArrayList<String>();
		 for (String value : hm.values())  
	            arl.add(value);
		 Collections.sort(arl);
		 return arl;
		
	}

	}


