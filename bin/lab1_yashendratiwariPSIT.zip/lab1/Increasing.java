package lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Increasing {

	public static void main(String[] args) {
		int n;
		boolean ans;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			ans = checkNumber(n);
			System.out.println("Number being increasing is "+ans);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static boolean checkNumber(int n) {
		boolean flag = true;
		while(n>0)
		{
			int rem1  = n % 10;
			n /= 10;
			if(rem1<n%10)
			{
				flag = false;
				break;
			}
		}
		return flag;
	}

}
