package lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PowerOfTwo {

	public static void main(String[] args) {
		
		int n;
		boolean flag;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			flag = checkNumber(n);
			System.out.println("Number being power of two is "+flag);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static boolean checkNumber(int n) {
		boolean flag = true;
		//System.out.println(n<<1);
		String s = Integer.toBinaryString(n);
		if(Integer.valueOf(s.substring(1)) != 0)
			flag = false;
		return flag;
	}

}
