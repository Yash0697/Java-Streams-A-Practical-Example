package lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SumDiv {

	public static void main(String[] args) {
		int n, sum;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			sum = calculateSum(n);
			System.out.println("Sum is "+sum);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static int calculateSum(int n) {
		int sum = 0;
		while(n>0)
		{
			if(n % 3 == 0 || n % 5 == 0)
			{
				sum += n;
			}
			n--;
		}
		return sum;
	}

}
