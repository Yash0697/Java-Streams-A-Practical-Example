package lab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DiffSquares {

	public static void main(String[] args) {
		int n, diff;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value of n");
		try {
			n = Integer.parseInt(br.readLine());
			diff = calculateDifference(n);
			System.out.println("Difference of Sum of squares and squares of sum is "+diff);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	 static int calculateDifference(int n) {
		int diff = 0;
		int squareSum  = (int)n*(n+1)*(2*n+1)/6;
		int sumSquare = (int) Math.pow(n*(n+1)/2, 2);
		diff = squareSum - sumSquare;
		return diff;
	}

}
