package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class SecondLargestFinder {

	static int getSecondSmallest(int[] elements)
	{
		int secondSmallest,length,index1,index2;
		length = elements.length;
		Arrays.sort(elements);
		secondSmallest = elements[1];
		return secondSmallest;
		
	}
	
	public static void main(String[] args) {
		int numOfnums,index,secondSmallest;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Number of elements in array : ");
		try {
			numOfnums = Integer.parseInt(bufferedReader.readLine());
			int[] elements = new int[numOfnums];
			System.out.println("Enter Elements of Array : ");
			for(index=0;index<numOfnums;index++)
			{
				elements[index] = Integer.parseInt(bufferedReader.readLine());
			}
			
			secondSmallest = getSecondSmallest(elements);
			System.out.println("Second Smallest Element is "+secondSmallest);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
