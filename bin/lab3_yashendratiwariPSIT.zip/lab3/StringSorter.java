package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class StringSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numOfStrings, index;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter no of Strings :");
		try {
			numOfStrings = Integer.parseInt(bufferedReader.readLine());
			String [] strings = new String[numOfStrings];
			System.out.println("Enter "+numOfStrings+" strings : ");
			for(index = 0; index < strings.length; index++)
			{
				strings[index] = bufferedReader.readLine();
			}
			String[] ansArray = new String[numOfStrings];
			ansArray = sortStrings(strings);
			for(index = 0; index < numOfStrings; index++)
				System.out.print(ansArray[index]+"\t");
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}

	 static String[] sortStrings(String[] strings) {
		 Arrays.sort(strings);
		 int index;
		 double length = strings.length;
		 for(index = 0; index < Math.ceil(length/2); index++)
		 {
			 strings[index] = strings[index].toUpperCase(); 
		 }
		 for(index = (int) Math.ceil(length/2); index < length; index++)
		 {
			 strings[index] = strings[index].toLowerCase(); 
		 }
		 return strings;
	}

}
