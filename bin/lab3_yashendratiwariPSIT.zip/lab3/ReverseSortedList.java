package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class ReverseSortedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int numOfnums,index;
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Number of elements in array : ");
		try {
			numOfnums = Integer.parseInt(bufferedReader.readLine());
			int[] elements = new int[numOfnums];
			int ansArray[] = new int[numOfnums];
			System.out.println("Enter Elements of Array : ");
			for(index=0;index<numOfnums;index++)
			{
				elements[index] = Integer.parseInt(bufferedReader.readLine());
			}
			
			ansArray = getSorted(elements);
			for(index = 0; index < numOfnums; index++)
			System.out.print(ansArray[index]+" ");
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
	}

	 static int[] getSorted(int[] elements) {
		 int[] tempArray = new int[elements.length];
		 int index, index2, numOfnums, num, temp;
		 numOfnums = elements.length;
		 index2 = 0;
		 for(index = 0; index < numOfnums; index++)
		 {
			 num = elements[index];
			 StringBuffer sb = new StringBuffer();
			 sb.append(num);
			 sb.reverse();
			 temp = Integer.parseInt(sb.toString());
			 tempArray[index2] = temp;
			 index2++;
		 }
		 Arrays.sort(tempArray);
		 return tempArray;
	}

	 

}
